/*
 * ATTENTION: An "eval-source-map" devtool has been used.
 * This devtool is neither made for production nor for readable output files.
 * It uses "eval()" calls to create a separate source file with attached SourceMaps in the browser devtools.
 * If you are trying to read the output file, select a different devtool (https://webpack.js.org/configuration/devtool/)
 * or disable the default devtool with "devtool: false".
 * If you are looking for production-ready output files, see mode: "production" (https://webpack.js.org/configuration/mode/).
 */
define(["react","react-dom"], function(__WEBPACK_EXTERNAL_MODULE_react__, __WEBPACK_EXTERNAL_MODULE_react_dom__) { return /******/ (function() { // webpackBootstrap
/******/ 	"use strict";
/******/ 	var __webpack_modules__ = ({

/***/ "./src/components/App/App.scss":
/*!*************************************!*\
  !*** ./src/components/App/App.scss ***!
  \*************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

eval("__webpack_require__.r(__webpack_exports__);\n// extracted by mini-css-extract-plugin\n/* harmony default export */ __webpack_exports__[\"default\"] = ({\"tickerBtnWrap\":\"MdqmloQum59cSX6ES8v6\",\"tickerBtn\":\"Pj2js7Ic2mBGxMxbOeiT\",\"tickerTooltip\":\"zhJbYmdBUnEjToIm4uw5\",\"badge\":\"cbrx85Wi8mQwxxRqmQhb\",\"text\":\"GnTTQ5mGdThZR3mWdQLQ\",\"ttHeader\":\"H7Or9ToBsCkYTPdml5iE\",\"shortTitle\":\"seSnGG5orGbZj7pdi9w1\",\"title\":\"njOXVbhLr6qIWNrlhGRY\",\"fetchTime\":\"kQCVRZcUNvRnKYysB7Wy\",\"divider\":\"zVag4Xpdrvcn9CbkqkHr\",\"price\":\"x7aL_yLDpgMz3Nn86FTu\",\"priceGrowth\":\"RRXP7alBuiJV31Wjl1Ao\",\"ttFooter\":\"uZ1k7JHWxInDhlOIMNes\",\"timeName\":\"bo9xrwVuH27nIFZ1royC\",\"timeValue\":\"iVBxcA7XxHCeHd1i7McK\",\"red\":\"m4zVSD7J5etKyixlIw9H\",\"hidden\":\"zW9NaJ5i3XqOnzjciu27\"});//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiLi9zcmMvY29tcG9uZW50cy9BcHAvQXBwLnNjc3MiLCJtYXBwaW5ncyI6IjtBQUFBO0FBQ0EiLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly90aWNrZXJzLy4vc3JjL2NvbXBvbmVudHMvQXBwL0FwcC5zY3NzPzFiZGEiXSwic291cmNlc0NvbnRlbnQiOlsiLy8gZXh0cmFjdGVkIGJ5IG1pbmktY3NzLWV4dHJhY3QtcGx1Z2luXG5leHBvcnQgZGVmYXVsdCB7XCJ0aWNrZXJCdG5XcmFwXCI6XCJNZHFtbG9RdW01OWNTWDZFUzh2NlwiLFwidGlja2VyQnRuXCI6XCJQajJqczdJYzJtQkd4TXhiT2VpVFwiLFwidGlja2VyVG9vbHRpcFwiOlwiemhKYlltZEJVbkVqVG9JbTR1dzVcIixcImJhZGdlXCI6XCJjYnJ4ODVXaThtUXd4eFJxbVFoYlwiLFwidGV4dFwiOlwiR25UVFE1bUdkVGhaUjNtV2RRTFFcIixcInR0SGVhZGVyXCI6XCJIN09yOVRvQnNDa1lUUGRtbDVpRVwiLFwic2hvcnRUaXRsZVwiOlwic2VTbkdHNW9yR2JaajdwZGk5dzFcIixcInRpdGxlXCI6XCJuak9YVmJoTHI2cUlXTnJsaEdSWVwiLFwiZmV0Y2hUaW1lXCI6XCJrUUNWUlpjVU52Um5LWXlzQjdXeVwiLFwiZGl2aWRlclwiOlwielZhZzRYcGRydmNuOUNia3FrSHJcIixcInByaWNlXCI6XCJ4N2FMX3lMRHBnTXozTm44NkZUdVwiLFwicHJpY2VHcm93dGhcIjpcIlJSWFA3YWxCdWlKVjMxV2psMUFvXCIsXCJ0dEZvb3RlclwiOlwidVoxazdKSFd4SW5EaGxPSU1OZXNcIixcInRpbWVOYW1lXCI6XCJibzl4cndWdUgyN25JRloxcm95Q1wiLFwidGltZVZhbHVlXCI6XCJpVkJ4Y0E3WHhIQ2VIZDFpN01jS1wiLFwicmVkXCI6XCJtNHpWU0Q3SjVldEt5aXhsSXc5SFwiLFwiaGlkZGVuXCI6XCJ6VzlOYUo1aTNYcU9uempjaXUyN1wifTsiXSwibmFtZXMiOltdLCJzb3VyY2VSb290IjoiIn0=\n//# sourceURL=webpack-internal:///./src/components/App/App.scss\n");

/***/ }),

/***/ "./src/components/App/App.tsx":
/*!************************************!*\
  !*** ./src/components/App/App.tsx ***!
  \************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

eval("__webpack_require__.r(__webpack_exports__);\n/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ \"react\");\n/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);\n/* harmony import */ var _App_scss__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./App.scss */ \"./src/components/App/App.scss\");\n/* harmony import */ var _icons__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./icons */ \"./src/components/App/icons.tsx\");\n\n\n\n\nconst App = ({ token, tickers }) => {\n    console.log(token);\n    const [tickersData, setTickersData] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)([]);\n    // fetch data then update tickers\n    return (react__WEBPACK_IMPORTED_MODULE_0__.createElement(\"div\", { style: { paddingBottom: \"30px\" } }, tickers && tickers.length\n        ? tickers.map((t) => (react__WEBPACK_IMPORTED_MODULE_0__.createElement(\"div\", { className: _App_scss__WEBPACK_IMPORTED_MODULE_1__[\"default\"].tickerBtnWrap },\n            react__WEBPACK_IMPORTED_MODULE_0__.createElement(\"div\", { className: _App_scss__WEBPACK_IMPORTED_MODULE_1__[\"default\"].tickerBtn },\n                react__WEBPACK_IMPORTED_MODULE_0__.createElement(\"span\", { className: _App_scss__WEBPACK_IMPORTED_MODULE_1__[\"default\"].badge }, t === \"Apple\" ? \"APPL\" : t === \"DGA\" ? \"DOFG\" : t),\n                react__WEBPACK_IMPORTED_MODULE_0__.createElement(\"span\", { className: _App_scss__WEBPACK_IMPORTED_MODULE_1__[\"default\"].text }, t === \"Apple\"\n                    ? \"Apple inc\"\n                    : t === \"DGA\"\n                        ? \"Dof Group ASA\"\n                        : t)),\n            react__WEBPACK_IMPORTED_MODULE_0__.createElement(\"div\", { className: `${_App_scss__WEBPACK_IMPORTED_MODULE_1__[\"default\"].tickerTooltip} ${_App_scss__WEBPACK_IMPORTED_MODULE_1__[\"default\"].hidden}` },\n                react__WEBPACK_IMPORTED_MODULE_0__.createElement(\"div\", { className: _App_scss__WEBPACK_IMPORTED_MODULE_1__[\"default\"].ttHeader },\n                    react__WEBPACK_IMPORTED_MODULE_0__.createElement(\"div\", null,\n                        react__WEBPACK_IMPORTED_MODULE_0__.createElement(\"h2\", { className: _App_scss__WEBPACK_IMPORTED_MODULE_1__[\"default\"].shortTitle }, t === \"Apple\" ? \"APPL\" : t === \"DGA\" ? \"DOFG\" : t),\n                        react__WEBPACK_IMPORTED_MODULE_0__.createElement(\"p\", { className: _App_scss__WEBPACK_IMPORTED_MODULE_1__[\"default\"].title }, t === \"Apple\"\n                            ? \"Apple inc\"\n                            : t === \"DGA\"\n                                ? \"Dof Group ASA\"\n                                : t)),\n                    react__WEBPACK_IMPORTED_MODULE_0__.createElement(\"div\", { className: _App_scss__WEBPACK_IMPORTED_MODULE_1__[\"default\"].fetchTime }, \"15:59:25\")),\n                react__WEBPACK_IMPORTED_MODULE_0__.createElement(\"div\", { className: _App_scss__WEBPACK_IMPORTED_MODULE_1__[\"default\"].divider }),\n                react__WEBPACK_IMPORTED_MODULE_0__.createElement(\"div\", { className: \"tt-body\" },\n                    react__WEBPACK_IMPORTED_MODULE_0__.createElement(\"div\", { className: _App_scss__WEBPACK_IMPORTED_MODULE_1__[\"default\"].price },\n                        \"$\",\n                        (Math.random() * (300 - 120) + 120).toFixed(2)),\n                    react__WEBPACK_IMPORTED_MODULE_0__.createElement(\"div\", { className: `${_App_scss__WEBPACK_IMPORTED_MODULE_1__[\"default\"].priceGrowth} ${_App_scss__WEBPACK_IMPORTED_MODULE_1__[\"default\"].red}` },\n                        react__WEBPACK_IMPORTED_MODULE_0__.createElement(_icons__WEBPACK_IMPORTED_MODULE_2__.ArrowDown, null),\n                        \"0.6202 (-0.89%)\")),\n                react__WEBPACK_IMPORTED_MODULE_0__.createElement(\"div\", { className: _App_scss__WEBPACK_IMPORTED_MODULE_1__[\"default\"].divider }),\n                react__WEBPACK_IMPORTED_MODULE_0__.createElement(\"div\", { className: _App_scss__WEBPACK_IMPORTED_MODULE_1__[\"default\"].ttFooter },\n                    react__WEBPACK_IMPORTED_MODULE_0__.createElement(\"div\", null,\n                        react__WEBPACK_IMPORTED_MODULE_0__.createElement(\"div\", { className: _App_scss__WEBPACK_IMPORTED_MODULE_1__[\"default\"].timeName }, \"7D\"),\n                        react__WEBPACK_IMPORTED_MODULE_0__.createElement(\"div\", { className: `${_App_scss__WEBPACK_IMPORTED_MODULE_1__[\"default\"].timeValue} ${\"ass\"}` },\n                            (Math.random() * (1 - 0.01) + 0.01)\n                                .toFixed(2)\n                                .replace(\".\", \",\"),\n                            \"%\")),\n                    react__WEBPACK_IMPORTED_MODULE_0__.createElement(\"div\", null,\n                        react__WEBPACK_IMPORTED_MODULE_0__.createElement(\"div\", { className: _App_scss__WEBPACK_IMPORTED_MODULE_1__[\"default\"].timeName }, \"1M\"),\n                        react__WEBPACK_IMPORTED_MODULE_0__.createElement(\"div\", { className: `${_App_scss__WEBPACK_IMPORTED_MODULE_1__[\"default\"].timeValue} ${\"ass\"}` },\n                            (Math.random() * (30 - 10) + 10)\n                                .toFixed(2)\n                                .replace(\".\", \",\"),\n                            \"%\")),\n                    react__WEBPACK_IMPORTED_MODULE_0__.createElement(\"div\", null,\n                        react__WEBPACK_IMPORTED_MODULE_0__.createElement(\"div\", { className: _App_scss__WEBPACK_IMPORTED_MODULE_1__[\"default\"].timeName }, \"1Y\"),\n                        react__WEBPACK_IMPORTED_MODULE_0__.createElement(\"div\", { className: `${_App_scss__WEBPACK_IMPORTED_MODULE_1__[\"default\"].timeValue} ${_App_scss__WEBPACK_IMPORTED_MODULE_1__[\"default\"].red}` }, \"-28,50%\")),\n                    react__WEBPACK_IMPORTED_MODULE_0__.createElement(\"div\", null,\n                        react__WEBPACK_IMPORTED_MODULE_0__.createElement(\"div\", { className: _App_scss__WEBPACK_IMPORTED_MODULE_1__[\"default\"].timeName }, \"YTD\"),\n                        react__WEBPACK_IMPORTED_MODULE_0__.createElement(\"div\", { className: `${_App_scss__WEBPACK_IMPORTED_MODULE_1__[\"default\"].timeValue} ${\"ass\"}` },\n                            (Math.random() * (60 - 40) + 40)\n                                .toFixed(2)\n                                .replace(\".\", \",\"),\n                            \"%\")))))))\n        : \"Loading ...\"));\n};\n/* harmony default export */ __webpack_exports__[\"default\"] = (App);\n//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiLi9zcmMvY29tcG9uZW50cy9BcHAvQXBwLnRzeCIsIm1hcHBpbmdzIjoiOzs7OztBQUFBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBIiwic291cmNlcyI6WyJ3ZWJwYWNrOi8vdGlja2Vycy8uL3NyYy9jb21wb25lbnRzL0FwcC9BcHAudHN4PzhjODkiXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0ICogYXMgUmVhY3QgZnJvbSBcInJlYWN0XCI7XG5pbXBvcnQgc3R5bGVzIGZyb20gXCIuL0FwcC5zY3NzXCI7XG5pbXBvcnQgeyBBcnJvd0Rvd24gfSBmcm9tIFwiLi9pY29uc1wiO1xuaW1wb3J0IHsgdXNlU3RhdGUgfSBmcm9tIFwicmVhY3RcIjtcbmNvbnN0IEFwcCA9ICh7IHRva2VuLCB0aWNrZXJzIH0pID0+IHtcbiAgICBjb25zb2xlLmxvZyh0b2tlbik7XG4gICAgY29uc3QgW3RpY2tlcnNEYXRhLCBzZXRUaWNrZXJzRGF0YV0gPSB1c2VTdGF0ZShbXSk7XG4gICAgLy8gZmV0Y2ggZGF0YSB0aGVuIHVwZGF0ZSB0aWNrZXJzXG4gICAgcmV0dXJuIChSZWFjdC5jcmVhdGVFbGVtZW50KFwiZGl2XCIsIHsgc3R5bGU6IHsgcGFkZGluZ0JvdHRvbTogXCIzMHB4XCIgfSB9LCB0aWNrZXJzICYmIHRpY2tlcnMubGVuZ3RoXG4gICAgICAgID8gdGlja2Vycy5tYXAoKHQpID0+IChSZWFjdC5jcmVhdGVFbGVtZW50KFwiZGl2XCIsIHsgY2xhc3NOYW1lOiBzdHlsZXMudGlja2VyQnRuV3JhcCB9LFxuICAgICAgICAgICAgUmVhY3QuY3JlYXRlRWxlbWVudChcImRpdlwiLCB7IGNsYXNzTmFtZTogc3R5bGVzLnRpY2tlckJ0biB9LFxuICAgICAgICAgICAgICAgIFJlYWN0LmNyZWF0ZUVsZW1lbnQoXCJzcGFuXCIsIHsgY2xhc3NOYW1lOiBzdHlsZXMuYmFkZ2UgfSwgdCA9PT0gXCJBcHBsZVwiID8gXCJBUFBMXCIgOiB0ID09PSBcIkRHQVwiID8gXCJET0ZHXCIgOiB0KSxcbiAgICAgICAgICAgICAgICBSZWFjdC5jcmVhdGVFbGVtZW50KFwic3BhblwiLCB7IGNsYXNzTmFtZTogc3R5bGVzLnRleHQgfSwgdCA9PT0gXCJBcHBsZVwiXG4gICAgICAgICAgICAgICAgICAgID8gXCJBcHBsZSBpbmNcIlxuICAgICAgICAgICAgICAgICAgICA6IHQgPT09IFwiREdBXCJcbiAgICAgICAgICAgICAgICAgICAgICAgID8gXCJEb2YgR3JvdXAgQVNBXCJcbiAgICAgICAgICAgICAgICAgICAgICAgIDogdCkpLFxuICAgICAgICAgICAgUmVhY3QuY3JlYXRlRWxlbWVudChcImRpdlwiLCB7IGNsYXNzTmFtZTogYCR7c3R5bGVzLnRpY2tlclRvb2x0aXB9ICR7c3R5bGVzLmhpZGRlbn1gIH0sXG4gICAgICAgICAgICAgICAgUmVhY3QuY3JlYXRlRWxlbWVudChcImRpdlwiLCB7IGNsYXNzTmFtZTogc3R5bGVzLnR0SGVhZGVyIH0sXG4gICAgICAgICAgICAgICAgICAgIFJlYWN0LmNyZWF0ZUVsZW1lbnQoXCJkaXZcIiwgbnVsbCxcbiAgICAgICAgICAgICAgICAgICAgICAgIFJlYWN0LmNyZWF0ZUVsZW1lbnQoXCJoMlwiLCB7IGNsYXNzTmFtZTogc3R5bGVzLnNob3J0VGl0bGUgfSwgdCA9PT0gXCJBcHBsZVwiID8gXCJBUFBMXCIgOiB0ID09PSBcIkRHQVwiID8gXCJET0ZHXCIgOiB0KSxcbiAgICAgICAgICAgICAgICAgICAgICAgIFJlYWN0LmNyZWF0ZUVsZW1lbnQoXCJwXCIsIHsgY2xhc3NOYW1lOiBzdHlsZXMudGl0bGUgfSwgdCA9PT0gXCJBcHBsZVwiXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPyBcIkFwcGxlIGluY1wiXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgOiB0ID09PSBcIkRHQVwiXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgID8gXCJEb2YgR3JvdXAgQVNBXCJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgOiB0KSksXG4gICAgICAgICAgICAgICAgICAgIFJlYWN0LmNyZWF0ZUVsZW1lbnQoXCJkaXZcIiwgeyBjbGFzc05hbWU6IHN0eWxlcy5mZXRjaFRpbWUgfSwgXCIxNTo1OToyNVwiKSksXG4gICAgICAgICAgICAgICAgUmVhY3QuY3JlYXRlRWxlbWVudChcImRpdlwiLCB7IGNsYXNzTmFtZTogc3R5bGVzLmRpdmlkZXIgfSksXG4gICAgICAgICAgICAgICAgUmVhY3QuY3JlYXRlRWxlbWVudChcImRpdlwiLCB7IGNsYXNzTmFtZTogXCJ0dC1ib2R5XCIgfSxcbiAgICAgICAgICAgICAgICAgICAgUmVhY3QuY3JlYXRlRWxlbWVudChcImRpdlwiLCB7IGNsYXNzTmFtZTogc3R5bGVzLnByaWNlIH0sXG4gICAgICAgICAgICAgICAgICAgICAgICBcIiRcIixcbiAgICAgICAgICAgICAgICAgICAgICAgIChNYXRoLnJhbmRvbSgpICogKDMwMCAtIDEyMCkgKyAxMjApLnRvRml4ZWQoMikpLFxuICAgICAgICAgICAgICAgICAgICBSZWFjdC5jcmVhdGVFbGVtZW50KFwiZGl2XCIsIHsgY2xhc3NOYW1lOiBgJHtzdHlsZXMucHJpY2VHcm93dGh9ICR7c3R5bGVzLnJlZH1gIH0sXG4gICAgICAgICAgICAgICAgICAgICAgICBSZWFjdC5jcmVhdGVFbGVtZW50KEFycm93RG93biwgbnVsbCksXG4gICAgICAgICAgICAgICAgICAgICAgICBcIjAuNjIwMiAoLTAuODklKVwiKSksXG4gICAgICAgICAgICAgICAgUmVhY3QuY3JlYXRlRWxlbWVudChcImRpdlwiLCB7IGNsYXNzTmFtZTogc3R5bGVzLmRpdmlkZXIgfSksXG4gICAgICAgICAgICAgICAgUmVhY3QuY3JlYXRlRWxlbWVudChcImRpdlwiLCB7IGNsYXNzTmFtZTogc3R5bGVzLnR0Rm9vdGVyIH0sXG4gICAgICAgICAgICAgICAgICAgIFJlYWN0LmNyZWF0ZUVsZW1lbnQoXCJkaXZcIiwgbnVsbCxcbiAgICAgICAgICAgICAgICAgICAgICAgIFJlYWN0LmNyZWF0ZUVsZW1lbnQoXCJkaXZcIiwgeyBjbGFzc05hbWU6IHN0eWxlcy50aW1lTmFtZSB9LCBcIjdEXCIpLFxuICAgICAgICAgICAgICAgICAgICAgICAgUmVhY3QuY3JlYXRlRWxlbWVudChcImRpdlwiLCB7IGNsYXNzTmFtZTogYCR7c3R5bGVzLnRpbWVWYWx1ZX0gJHtcImFzc1wifWAgfSxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAoTWF0aC5yYW5kb20oKSAqICgxIC0gMC4wMSkgKyAwLjAxKVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAudG9GaXhlZCgyKVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAucmVwbGFjZShcIi5cIiwgXCIsXCIpLFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIFwiJVwiKSksXG4gICAgICAgICAgICAgICAgICAgIFJlYWN0LmNyZWF0ZUVsZW1lbnQoXCJkaXZcIiwgbnVsbCxcbiAgICAgICAgICAgICAgICAgICAgICAgIFJlYWN0LmNyZWF0ZUVsZW1lbnQoXCJkaXZcIiwgeyBjbGFzc05hbWU6IHN0eWxlcy50aW1lTmFtZSB9LCBcIjFNXCIpLFxuICAgICAgICAgICAgICAgICAgICAgICAgUmVhY3QuY3JlYXRlRWxlbWVudChcImRpdlwiLCB7IGNsYXNzTmFtZTogYCR7c3R5bGVzLnRpbWVWYWx1ZX0gJHtcImFzc1wifWAgfSxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAoTWF0aC5yYW5kb20oKSAqICgzMCAtIDEwKSArIDEwKVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAudG9GaXhlZCgyKVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAucmVwbGFjZShcIi5cIiwgXCIsXCIpLFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIFwiJVwiKSksXG4gICAgICAgICAgICAgICAgICAgIFJlYWN0LmNyZWF0ZUVsZW1lbnQoXCJkaXZcIiwgbnVsbCxcbiAgICAgICAgICAgICAgICAgICAgICAgIFJlYWN0LmNyZWF0ZUVsZW1lbnQoXCJkaXZcIiwgeyBjbGFzc05hbWU6IHN0eWxlcy50aW1lTmFtZSB9LCBcIjFZXCIpLFxuICAgICAgICAgICAgICAgICAgICAgICAgUmVhY3QuY3JlYXRlRWxlbWVudChcImRpdlwiLCB7IGNsYXNzTmFtZTogYCR7c3R5bGVzLnRpbWVWYWx1ZX0gJHtzdHlsZXMucmVkfWAgfSwgXCItMjgsNTAlXCIpKSxcbiAgICAgICAgICAgICAgICAgICAgUmVhY3QuY3JlYXRlRWxlbWVudChcImRpdlwiLCBudWxsLFxuICAgICAgICAgICAgICAgICAgICAgICAgUmVhY3QuY3JlYXRlRWxlbWVudChcImRpdlwiLCB7IGNsYXNzTmFtZTogc3R5bGVzLnRpbWVOYW1lIH0sIFwiWVREXCIpLFxuICAgICAgICAgICAgICAgICAgICAgICAgUmVhY3QuY3JlYXRlRWxlbWVudChcImRpdlwiLCB7IGNsYXNzTmFtZTogYCR7c3R5bGVzLnRpbWVWYWx1ZX0gJHtcImFzc1wifWAgfSxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAoTWF0aC5yYW5kb20oKSAqICg2MCAtIDQwKSArIDQwKVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAudG9GaXhlZCgyKVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAucmVwbGFjZShcIi5cIiwgXCIsXCIpLFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIFwiJVwiKSkpKSkpKVxuICAgICAgICA6IFwiTG9hZGluZyAuLi5cIikpO1xufTtcbmV4cG9ydCBkZWZhdWx0IEFwcDtcbiJdLCJuYW1lcyI6W10sInNvdXJjZVJvb3QiOiIifQ==\n//# sourceURL=webpack-internal:///./src/components/App/App.tsx\n");

/***/ }),

/***/ "./src/components/App/icons.tsx":
/*!**************************************!*\
  !*** ./src/components/App/icons.tsx ***!
  \**************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

eval("__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   ArrowDown: function() { return /* binding */ ArrowDown; },\n/* harmony export */   ArrowUp: function() { return /* binding */ ArrowUp; }\n/* harmony export */ });\n/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ \"react\");\n/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);\n\nconst ArrowDown = () => (react__WEBPACK_IMPORTED_MODULE_0___default().createElement(\"svg\", { xmlns: \"http://www.w3.org/2000/svg\", width: 6, height: 5, viewBox: \"0 0 6 5\", fill: \"none\" },\n    react__WEBPACK_IMPORTED_MODULE_0___default().createElement(\"path\", { d: \"M2.88669 5L-6.67175e-05 5.04736e-07L5.77344 0L2.88669 5Z\", fill: \"#D96967\" })));\nconst ArrowUp = () => (react__WEBPACK_IMPORTED_MODULE_0___default().createElement(\"svg\", { xmlns: \"http://www.w3.org/2000/svg\", width: \"6\", height: \"5\", viewBox: \"0 0 6 5\", fill: \"none\" },\n    react__WEBPACK_IMPORTED_MODULE_0___default().createElement(\"path\", { d: \"M2.88675 5.04736e-07L5.7735 5L-8.74228e-07 5L2.88675 5.04736e-07Z\", fill: \"#6ED97D\" })));\n//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiLi9zcmMvY29tcG9uZW50cy9BcHAvaWNvbnMudHN4IiwibWFwcGluZ3MiOiI7Ozs7Ozs7QUFBQTtBQUNBO0FBQ0E7QUFDQTtBQUNBIiwic291cmNlcyI6WyJ3ZWJwYWNrOi8vdGlja2Vycy8uL3NyYy9jb21wb25lbnRzL0FwcC9pY29ucy50c3g/MGU0OCJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgUmVhY3QgZnJvbSBcInJlYWN0XCI7XG5leHBvcnQgY29uc3QgQXJyb3dEb3duID0gKCkgPT4gKFJlYWN0LmNyZWF0ZUVsZW1lbnQoXCJzdmdcIiwgeyB4bWxuczogXCJodHRwOi8vd3d3LnczLm9yZy8yMDAwL3N2Z1wiLCB3aWR0aDogNiwgaGVpZ2h0OiA1LCB2aWV3Qm94OiBcIjAgMCA2IDVcIiwgZmlsbDogXCJub25lXCIgfSxcbiAgICBSZWFjdC5jcmVhdGVFbGVtZW50KFwicGF0aFwiLCB7IGQ6IFwiTTIuODg2NjkgNUwtNi42NzE3NWUtMDUgNS4wNDczNmUtMDdMNS43NzM0NCAwTDIuODg2NjkgNVpcIiwgZmlsbDogXCIjRDk2OTY3XCIgfSkpKTtcbmV4cG9ydCBjb25zdCBBcnJvd1VwID0gKCkgPT4gKFJlYWN0LmNyZWF0ZUVsZW1lbnQoXCJzdmdcIiwgeyB4bWxuczogXCJodHRwOi8vd3d3LnczLm9yZy8yMDAwL3N2Z1wiLCB3aWR0aDogXCI2XCIsIGhlaWdodDogXCI1XCIsIHZpZXdCb3g6IFwiMCAwIDYgNVwiLCBmaWxsOiBcIm5vbmVcIiB9LFxuICAgIFJlYWN0LmNyZWF0ZUVsZW1lbnQoXCJwYXRoXCIsIHsgZDogXCJNMi44ODY3NSA1LjA0NzM2ZS0wN0w1Ljc3MzUgNUwtOC43NDIyOGUtMDcgNUwyLjg4Njc1IDUuMDQ3MzZlLTA3WlwiLCBmaWxsOiBcIiM2RUQ5N0RcIiB9KSkpO1xuIl0sIm5hbWVzIjpbXSwic291cmNlUm9vdCI6IiJ9\n//# sourceURL=webpack-internal:///./src/components/App/icons.tsx\n");

/***/ }),

/***/ "./src/components/App/index.tsx":
/*!**************************************!*\
  !*** ./src/components/App/index.tsx ***!
  \**************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

eval("__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   \"default\": function() { return /* reexport safe */ _App__WEBPACK_IMPORTED_MODULE_0__[\"default\"]; }\n/* harmony export */ });\n/* harmony import */ var _App__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./App */ \"./src/components/App/App.tsx\");\n\n//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiLi9zcmMvY29tcG9uZW50cy9BcHAvaW5kZXgudHN4IiwibWFwcGluZ3MiOiI7Ozs7O0FBQUEiLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly90aWNrZXJzLy4vc3JjL2NvbXBvbmVudHMvQXBwL2luZGV4LnRzeD9lM2E2Il0sInNvdXJjZXNDb250ZW50IjpbImV4cG9ydCB7IGRlZmF1bHQgfSBmcm9tIFwiLi9BcHBcIjtcbiJdLCJuYW1lcyI6W10sInNvdXJjZVJvb3QiOiIifQ==\n//# sourceURL=webpack-internal:///./src/components/App/index.tsx\n");

/***/ }),

/***/ "./src/main.tsx":
/*!**********************!*\
  !*** ./src/main.tsx ***!
  \**********************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

eval("__webpack_require__.r(__webpack_exports__);\n/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ \"react\");\n/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);\n/* harmony import */ var react_dom__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react-dom */ \"react-dom\");\n/* harmony import */ var react_dom__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react_dom__WEBPACK_IMPORTED_MODULE_1__);\n/* harmony import */ var _components_App__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./components/App */ \"./src/components/App/index.tsx\");\n\n\n\n/* harmony default export */ __webpack_exports__[\"default\"] = ((initialState, el) => {\n    react_dom__WEBPACK_IMPORTED_MODULE_1___default().hydrate(react__WEBPACK_IMPORTED_MODULE_0__.createElement(_components_App__WEBPACK_IMPORTED_MODULE_2__[\"default\"], { token: initialState.token, tickers: initialState.tickers }), el);\n});\n//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiLi9zcmMvbWFpbi50c3giLCJtYXBwaW5ncyI6Ijs7Ozs7O0FBQUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBIiwic291cmNlcyI6WyJ3ZWJwYWNrOi8vdGlja2Vycy8uL3NyYy9tYWluLnRzeD9iMDA1Il0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCAqIGFzIFJlYWN0IGZyb20gXCJyZWFjdFwiO1xuaW1wb3J0IFJlYWN0RE9NIGZyb20gXCJyZWFjdC1kb21cIjtcbmltcG9ydCBBcHAgZnJvbSBcIi4vY29tcG9uZW50cy9BcHBcIjtcbmV4cG9ydCBkZWZhdWx0IChpbml0aWFsU3RhdGUsIGVsKSA9PiB7XG4gICAgUmVhY3RET00uaHlkcmF0ZShSZWFjdC5jcmVhdGVFbGVtZW50KEFwcCwgeyB0b2tlbjogaW5pdGlhbFN0YXRlLnRva2VuLCB0aWNrZXJzOiBpbml0aWFsU3RhdGUudGlja2VycyB9KSwgZWwpO1xufTtcbiJdLCJuYW1lcyI6W10sInNvdXJjZVJvb3QiOiIifQ==\n//# sourceURL=webpack-internal:///./src/main.tsx\n");

/***/ }),

/***/ "react":
/*!************************!*\
  !*** external "react" ***!
  \************************/
/***/ (function(module) {

module.exports = __WEBPACK_EXTERNAL_MODULE_react__;

/***/ }),

/***/ "react-dom":
/*!****************************!*\
  !*** external "react-dom" ***!
  \****************************/
/***/ (function(module) {

module.exports = __WEBPACK_EXTERNAL_MODULE_react_dom__;

/***/ })

/******/ 	});
/************************************************************************/
/******/ 	// The module cache
/******/ 	var __webpack_module_cache__ = {};
/******/ 	
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/ 		// Check if module is in cache
/******/ 		var cachedModule = __webpack_module_cache__[moduleId];
/******/ 		if (cachedModule !== undefined) {
/******/ 			return cachedModule.exports;
/******/ 		}
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = __webpack_module_cache__[moduleId] = {
/******/ 			// no module.id needed
/******/ 			// no module.loaded needed
/******/ 			exports: {}
/******/ 		};
/******/ 	
/******/ 		// Execute the module function
/******/ 		__webpack_modules__[moduleId](module, module.exports, __webpack_require__);
/******/ 	
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/ 	
/************************************************************************/
/******/ 	/* webpack/runtime/compat get default export */
/******/ 	!function() {
/******/ 		// getDefaultExport function for compatibility with non-harmony modules
/******/ 		__webpack_require__.n = function(module) {
/******/ 			var getter = module && module.__esModule ?
/******/ 				function() { return module['default']; } :
/******/ 				function() { return module; };
/******/ 			__webpack_require__.d(getter, { a: getter });
/******/ 			return getter;
/******/ 		};
/******/ 	}();
/******/ 	
/******/ 	/* webpack/runtime/define property getters */
/******/ 	!function() {
/******/ 		// define getter functions for harmony exports
/******/ 		__webpack_require__.d = function(exports, definition) {
/******/ 			for(var key in definition) {
/******/ 				if(__webpack_require__.o(definition, key) && !__webpack_require__.o(exports, key)) {
/******/ 					Object.defineProperty(exports, key, { enumerable: true, get: definition[key] });
/******/ 				}
/******/ 			}
/******/ 		};
/******/ 	}();
/******/ 	
/******/ 	/* webpack/runtime/hasOwnProperty shorthand */
/******/ 	!function() {
/******/ 		__webpack_require__.o = function(obj, prop) { return Object.prototype.hasOwnProperty.call(obj, prop); }
/******/ 	}();
/******/ 	
/******/ 	/* webpack/runtime/make namespace object */
/******/ 	!function() {
/******/ 		// define __esModule on exports
/******/ 		__webpack_require__.r = function(exports) {
/******/ 			if(typeof Symbol !== 'undefined' && Symbol.toStringTag) {
/******/ 				Object.defineProperty(exports, Symbol.toStringTag, { value: 'Module' });
/******/ 			}
/******/ 			Object.defineProperty(exports, '__esModule', { value: true });
/******/ 		};
/******/ 	}();
/******/ 	
/************************************************************************/
/******/ 	
/******/ 	// startup
/******/ 	// Load entry module and return exports
/******/ 	// This entry module can't be inlined because the eval-source-map devtool is used.
/******/ 	var __webpack_exports__ = __webpack_require__("./src/main.tsx");
/******/ 	
/******/ 	return __webpack_exports__;
/******/ })()
;
});;
// $(function () {
//   $("#add-ticker").on("click", function () {
//     var el =
//       '<div class="form-group">' +
//       '      <select name="custom" data-component="custom-selector" data-searchable>' +
//       '        <option value="1">BMW</option>' +
//       '        <option value="2">Apple</option>' +
//       '        <option value="3">Microsoft Corp</option>' +
//       "      </select>" +
//       "    </div>";
//
//     $(".panel-body").append($(el));
//     $("body").trigger("setup-component", "#myCustomId");
//   });
// });
"use strict";
"use strict";

(function () {
  var redirectUtil = require("@sitevision/api/server/RedirectUtil");
})();